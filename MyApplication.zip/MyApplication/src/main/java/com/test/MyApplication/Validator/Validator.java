package com.test.MyApplication.Validator;

public interface Validator {
}
