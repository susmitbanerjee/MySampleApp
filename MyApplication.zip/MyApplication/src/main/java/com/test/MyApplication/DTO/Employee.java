package com.test.MyApplication.DTO;

import org.springframework.stereotype.Component;

@Component
public class Employee {
    private int employeeid;
    private String Firstname;
    private String Surname;
    private String Dob;
    private String Address;
    private String Phnumber;
    private String Email;
    private String Zip;
    private String Bloodgroup;
    private String Location;

    public Employee(){

    }

    public Employee(String firstname, String surname, String dob, String address, String phnumber, String email, String zip, String bloodgroup, String location) {
        Firstname = firstname;
        Surname = surname;
        Dob = dob;
        Address = address;
        Phnumber = phnumber;
        Email = email;
        Zip = zip;
        Bloodgroup = bloodgroup;
        Location = location;
    }

    public int getEmployeeid() {
        return employeeid;
    }

    public void setEmployeeid(int employeeid) {
        this.employeeid = employeeid;
    }

    public String getFirstname() {
        return Firstname;
    }

    public void setFirstname(String firstname) {
        Firstname = firstname;
    }

    public String getSurname() {
        return Surname;
    }

    public void setSurname(String surname) {
        Surname = surname;
    }

    public String getDob() {
        return Dob;
    }

    public void setDob(String dob) {
        Dob = dob;
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String address) {
        Address = address;
    }

    public String getPhnumber() {
        return Phnumber;
    }

    public void setPhnumber(String phnumber) {
        Phnumber = phnumber;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public String getZip() {
        return Zip;
    }

    public void setZip(String zip) {
        Zip = zip;
    }

    public String getBloodgroup() {
        return Bloodgroup;
    }

    public void setBloodgroup(String bloodgroup) {
        Bloodgroup = bloodgroup;
    }

    public String getLocation() {
        return Location;
    }

    public void setLocation(String location) {
        Location = location;
    }
}
