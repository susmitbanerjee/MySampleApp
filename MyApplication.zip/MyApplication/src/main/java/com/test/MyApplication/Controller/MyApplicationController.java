package com.test.MyApplication.Controller;

import com.test.MyApplication.Service.LoginService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class MyApplicationController {

    @Autowired
    LoginService loginservice;

    @RequestMapping(value = "/")
    public String welcome() {
        return "welcome";
    }

    @RequestMapping(value = "/login", method = RequestMethod.GET)
    public String login(ModelMap model) {
        return "login";
    }

    @RequestMapping(value = "/login", method = RequestMethod.POST)
    public String showWelcomepage(ModelMap model, @RequestParam String name, @RequestParam String password){

        boolean isValidUser = loginservice.validateUser(name,password);
        if(!isValidUser){
            model.put("errorMessage","Invalid credentials");
            return "login";
        }
        model.put("name", name);
        return "success";
    }

    @RequestMapping(value = "/registration", method = RequestMethod.GET)
    public String registrastion(ModelMap model) {
        return "employee-registration";
    }
/*
    @RequestMapping(value = "/registration", method = RequestMethod.POST)
    public int show regustrationData(ModelMap model, ){

    }*/


}
