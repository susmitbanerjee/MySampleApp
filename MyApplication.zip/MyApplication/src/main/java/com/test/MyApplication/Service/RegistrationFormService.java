package com.test.MyApplication.Service;

import com.test.MyApplication.Validator.RegistrationFormValidator;
import com.test.MyApplication.Validator.Validator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


public class RegistrationFormService {

}
