package com.test.MyApplication.Validator;

import com.test.MyApplication.DTO.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.security.SecureRandom;

@Component
public class RegistrationFormValidator {

   /* @Autowired
    UserRepository userRepository;

    public int registrationformvalidator(String firstname, String surname, String dob, String address, String phnumber, String email, String zip, String bloodgroup, String location)
    {
        int id=0;
        if(firstname!=null||surname!=null||dob!=null||address!=null||phnumber!=null||email!=null||zip!=null||bloodgroup!=null||location!=null){
            Employee employee = new Employee();
            employee.setFirstname(firstname);
            employee.setSurname(surname);
            employee.setDob(dob);
            employee.setAddress(address);
            employee.setEmail(email);
            employee.setPhnumber(phnumber);
            employee.setZip(zip);
            employee.setBloodgroup(bloodgroup);
            employee.setLocation(location);
            try {
                userRepository.save(employee);
                employee.setEmployeeid(getRandomNumber());
            }catch(Exception e){
                e.printStackTrace();
            }
            id = employee.getEmployeeid();
        }
        return id;
    }

    public static int getRandomNumber(){
        SecureRandom secureRandom = new SecureRandom();
        return secureRandom.nextInt();
    }*/
}
